
def generate_prediction(concept):
    return f"L'IA prédit que {concept} a de fortes chances de se réaliser."
